history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
clear
cat /etc/debian_version
cat /etc/apt/sources.list
clear
apt update
clear
ip a
cat /etc/network/interfaces
cat /etc/resolv.conf
clear
cp /etc/apt/sources.list /etc/apt/sources.list.bak
echo deb http://deb.debian.org/debian bookworm main contrib non-free-firmware > /etc/apt/sources.list
echo deb http://security.debian.org/ bookworm-security main contrib non-free-firmware >> /etc/apt/sources.list
echo deb http://deb.debian.org/debian bookworm-updates main contrib non-free-firmware >> /etc/apt/sources.list
cat /etc/apt/sources.list
clear
apt update
clear
apt full-upgrade
clear
apt autoremove
reboot
clear
ls -l TP_scripts
lsblk
df -h /
clear
echo ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIDbkGP333n03XshUHTyowOB1AiP2pG8lGJIThFFxXUaK winscp >> .ssh/authorized_keys
cat .ssh/authorized_keys
