#!/bin/bash
# =====================================================================
# backup_full.sh - Punto 5 del TP
# Genera un backup comprimido (.tar.gz) de un directorio ORIGEN en DESTINO.
# El archivo se llama <nombre_del_directorio>_bkp_<AAAAMMDD>.tar.gz
#   Ej: /var/log  ->  log_bkp_20240302.tar.gz
# =====================================================================

# ---------- Funcion de ayuda (opcion -help) ----------
ayuda () {
    echo "Uso: $0 <origen> <destino>"
    echo ""
    echo "  <origen>   directorio a backupear (ej: /var/log)"
    echo "  <destino>  directorio donde se guarda el backup (ej: /backup_dir)"
    echo ""
    echo "El backup se guarda como <nombre>_bkp_<AAAAMMDD>.tar.gz"
    echo "Ejemplo: $0 /var/log /backup_dir  ->  /backup_dir/log_bkp_$(date +%Y%m%d).tar.gz"
    echo ""
    echo "Opciones:"
    echo "  -help    muestra esta ayuda"
}

# ---------- Opcion de ayuda ----------
if [[ "$1" == "-help" || "$1" == "-h" || "$1" == "--help" ]]; then
    ayuda
    exit 0
fi

# ---------- Validar cantidad de argumentos ($# = cantidad de argumentos) ----------
if [[ $# -ne 2 ]]; then
    echo "ERROR: se necesitan 2 argumentos (origen y destino)."
    ayuda
    exit 1
fi

# Quitamos la "/" final si la hubiera (ej: /var/log/ -> /var/log)
ORIGEN=${1%/}
DESTINO=${2%/}

# ---------- Validar que el ORIGEN exista y este disponible ----------
if [[ ! -d "$ORIGEN" ]]; then
    echo "ERROR: el origen $ORIGEN no existe o no es un directorio."
    exit 2
fi
if [[ ! -r "$ORIGEN" ]]; then
    echo "ERROR: no hay permisos de lectura sobre $ORIGEN."
    exit 2
fi
# Si el origen esta declarado como punto de montaje en /etc/fstab, debe estar montado
if grep -qE "[[:space:]]$ORIGEN[[:space:]]" /etc/fstab && ! mountpoint -q "$ORIGEN"; then
    echo "ERROR: el filesystem de origen $ORIGEN no esta montado."
    exit 2
fi

# ---------- Validar que el DESTINO exista y este disponible ----------
if [[ ! -d "$DESTINO" ]]; then
    echo "ERROR: el destino $DESTINO no existe o no es un directorio."
    exit 3
fi
if [[ ! -w "$DESTINO" ]]; then
    echo "ERROR: no hay permisos de escritura sobre $DESTINO."
    exit 3
fi
# Si el destino esta declarado en /etc/fstab (ej: /backup_dir), debe estar montado,
# asi el backup queda en la particion y no en el disco del sistema.
if grep -qE "[[:space:]]$DESTINO[[:space:]]" /etc/fstab && ! mountpoint -q "$DESTINO"; then
    echo "ERROR: el filesystem de destino $DESTINO no esta montado."
    exit 3
fi

# ---------- Armar el nombre del archivo con fecha ANSI (AAAAMMDD) ----------
NOMBRE=$(basename "$ORIGEN")
FECHA=$(date +%Y%m%d)
ARCHIVO="$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz"

# ---------- Hacer el backup ----------
echo "Backupeando $ORIGEN en $ARCHIVO ..."
# -c crear, -z comprimir con gzip, -f archivo; -C entra al directorio padre
tar -czf "$ARCHIVO" -C "$(dirname "$ORIGEN")" "$NOMBRE"

# $? = codigo de salida del comando anterior (0 = OK)
if [[ $? -eq 0 ]]; then
    echo "Backup OK: $ARCHIVO"
    exit 0
else
    echo "ERROR: fallo el backup de $ORIGEN"
    exit 4
fi
